-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 24, 2019 at 10:18 AM
-- Server version: 10.1.29-MariaDB
-- PHP Version: 7.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_rationapp`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_bank`
--

CREATE TABLE `tbl_bank` (
  `bank_id` int(11) NOT NULL,
  `holder` varchar(100) NOT NULL,
  `cvv` varchar(20) NOT NULL,
  `month` varchar(20) NOT NULL,
  `year` varchar(20) NOT NULL,
  `amount` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_bank`
--

INSERT INTO `tbl_bank` (`bank_id`, `holder`, `cvv`, `month`, `year`, `amount`) VALUES
(1, 'karthika', '12345', 'may', '2019', 9990);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_cart`
--

CREATE TABLE `tbl_cart` (
  `cart_id` int(11) NOT NULL,
  `uemail` varchar(100) NOT NULL,
  `pname` varchar(100) NOT NULL,
  `pqty` varchar(50) NOT NULL,
  `p_price` varchar(50) NOT NULL,
  `pimage` varchar(50) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_cart`
--

INSERT INTO `tbl_cart` (`cart_id`, `uemail`, `pname`, `pqty`, `p_price`, `pimage`, `status`) VALUES
(2, 'jyothi@gmail.com', 'Rice2', '10k', '2', 'Rice2.JPEG', 1),
(3, 'jyothi@gmail.com', 'Rice2', '10k', '2', 'Rice2.JPEG', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_complaint`
--

CREATE TABLE `tbl_complaint` (
  `complaint_id` int(11) NOT NULL,
  `uid` varchar(100) NOT NULL,
  `complaint` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_complaint`
--

INSERT INTO `tbl_complaint` (`complaint_id`, `uid`, `complaint`) VALUES
(2, 'jyothi@gma', 'bad');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_dealers`
--

CREATE TABLE `tbl_dealers` (
  `dealer_id` int(11) NOT NULL,
  `dealer_name` varchar(100) NOT NULL,
  `dealer_email` varchar(50) NOT NULL,
  `dealer_phone` bigint(50) NOT NULL,
  `dealer_licen` varchar(50) NOT NULL,
  `dealer_password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_dealers`
--

INSERT INTO `tbl_dealers` (`dealer_id`, `dealer_name`, `dealer_email`, `dealer_phone`, `dealer_licen`, `dealer_password`) VALUES
(2, 'musthafa', 'musthafa@gmail.com', 9539206718, 'L101', '1234'),
(3, 'nibil', 'nibil@gmail.com', 9539206718, 'L201', '0000000'),
(4, 'havila', 'havila@gmail.com', 9539286718, 'L03', '8520'),
(5, 'Rinju', 'rinju@gmail.com', 9539206718, 'L02', 'OTP8520'),
(6, 'joy', 'joy@gmail.com', 9539206718, 'L2111', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order`
--

CREATE TABLE `tbl_order` (
  `order_id` int(11) NOT NULL,
  `pid` varchar(10) NOT NULL,
  `uemail` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_order`
--

INSERT INTO `tbl_order` (`order_id`, `pid`, `uemail`) VALUES
(1, '2', 'jyothi@gmail.com'),
(2, '2', 'mm@gmail.com'),
(3, '2', 'jyothi@gmail.com'),
(5, '2', 'jyothi@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_product`
--

CREATE TABLE `tbl_product` (
  `prod_id` int(11) NOT NULL,
  `prod_name` varchar(50) NOT NULL,
  `prod_price` varchar(50) NOT NULL,
  `prod_qty` varchar(50) NOT NULL,
  `prod_apl` varchar(10) NOT NULL,
  `prod_bpl` varchar(10) NOT NULL,
  `prod_aay` varchar(10) NOT NULL,
  `prod_sub` varchar(10) NOT NULL,
  `prod_image` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_product`
--

INSERT INTO `tbl_product` (`prod_id`, `prod_name`, `prod_price`, `prod_qty`, `prod_apl`, `prod_bpl`, `prod_aay`, `prod_sub`, `prod_image`) VALUES
(2, 'Rice2', '2', '10k', '0', '1', '0', '1', 'Rice2.JPEG');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_ration_shop`
--

CREATE TABLE `tbl_ration_shop` (
  `shop_id` int(11) NOT NULL,
  `dealer_email` varchar(100) NOT NULL,
  `state` varchar(50) NOT NULL,
  `dist` varchar(50) NOT NULL,
  `city` varchar(50) NOT NULL,
  `latitude` varchar(50) NOT NULL,
  `longtitude` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_ration_shop`
--

INSERT INTO `tbl_ration_shop` (`shop_id`, `dealer_email`, `state`, `dist`, `city`, `latitude`, `longtitude`) VALUES
(1, 'musthafa@gmail.com', 'kerala', 'thrissur', 'puthur', '10.527641599999999', '76.2144349');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_users`
--

CREATE TABLE `tbl_users` (
  `user_id` int(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(50) NOT NULL,
  `card_no` varchar(50) NOT NULL,
  `proof_no` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_users`
--

INSERT INTO `tbl_users` (`user_id`, `email`, `username`, `password`, `card_no`, `proof_no`) VALUES
(3, 'musthafa@gmail.com', 'musthafa', '1234', 'C01', ''),
(4, 'musthafapulikkal@gmail.com', 'Musthafa', '4444', '123456', '2010'),
(5, 'jyothi@gmail.com', 'jyothi', '1234', '4321', '355'),
(7, 'praveen@gmail.com', 'praveen', '1234', 'C123', '123'),
(8, 'vinil@gmail.com', 'vinil', '1234', 'L123', 'C201');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_bank`
--
ALTER TABLE `tbl_bank`
  ADD PRIMARY KEY (`bank_id`);

--
-- Indexes for table `tbl_cart`
--
ALTER TABLE `tbl_cart`
  ADD PRIMARY KEY (`cart_id`);

--
-- Indexes for table `tbl_complaint`
--
ALTER TABLE `tbl_complaint`
  ADD PRIMARY KEY (`complaint_id`);

--
-- Indexes for table `tbl_dealers`
--
ALTER TABLE `tbl_dealers`
  ADD PRIMARY KEY (`dealer_id`);

--
-- Indexes for table `tbl_order`
--
ALTER TABLE `tbl_order`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `tbl_product`
--
ALTER TABLE `tbl_product`
  ADD PRIMARY KEY (`prod_id`);

--
-- Indexes for table `tbl_ration_shop`
--
ALTER TABLE `tbl_ration_shop`
  ADD PRIMARY KEY (`shop_id`);

--
-- Indexes for table `tbl_users`
--
ALTER TABLE `tbl_users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_bank`
--
ALTER TABLE `tbl_bank`
  MODIFY `bank_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_cart`
--
ALTER TABLE `tbl_cart`
  MODIFY `cart_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_complaint`
--
ALTER TABLE `tbl_complaint`
  MODIFY `complaint_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_dealers`
--
ALTER TABLE `tbl_dealers`
  MODIFY `dealer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tbl_order`
--
ALTER TABLE `tbl_order`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tbl_product`
--
ALTER TABLE `tbl_product`
  MODIFY `prod_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_ration_shop`
--
ALTER TABLE `tbl_ration_shop`
  MODIFY `shop_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_users`
--
ALTER TABLE `tbl_users`
  MODIFY `user_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
