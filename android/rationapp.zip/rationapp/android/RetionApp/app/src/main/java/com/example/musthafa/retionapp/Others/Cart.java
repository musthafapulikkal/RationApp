package com.example.musthafa.retionapp.Others;

import android.content.Context;

public class Cart {
    private String pname;
    private String pqty;
    private String price;
    private String image;
    private Context context;
    public Cart()
    {

    }

}
