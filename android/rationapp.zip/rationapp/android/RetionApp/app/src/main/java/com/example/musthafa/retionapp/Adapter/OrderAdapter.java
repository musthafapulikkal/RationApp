package com.example.musthafa.retionapp.Adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.musthafa.retionapp.Others.Orders;
import com.example.musthafa.retionapp.Others.Product;
import com.example.musthafa.retionapp.R;

import java.util.List;

public class OrderAdapter extends RecyclerView.Adapter<OrderAdapter.MyViewHolder> {
    private List<Orders> ordersList;
    private Context context;
    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView= LayoutInflater.from(parent.getContext()).inflate(R.layout.order_list,parent,false);
        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        final Orders orders=ordersList.get(position);
        holder.uemail.setText(orders.getUemail());
        holder.pname.setText(orders.getPname());
        String Url="http://192.168.100.131/rationapp/"+orders.getImage();
        Glide.with(orders.getContext()).load(Url).into(holder.imageView);
    }

    @Override
    public int getItemCount() {
        return ordersList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView uemail,pname;
        ImageView imageView;
        public MyViewHolder(View itemView) {
            super(itemView);
            uemail=(TextView)itemView.findViewById(R.id.id_dealer_uemail);
            pname=(TextView)itemView.findViewById(R.id.id_dealer_pname);
            imageView=(ImageView)itemView.findViewById(R.id.img_order);
        }
    }
    public OrderAdapter(List<Orders> ordersList){this.ordersList=ordersList;}
    public OrderAdapter(Context context){
        this.context=context;
    }
}
